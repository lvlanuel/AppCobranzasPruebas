package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    String WS2conec="",WS3conec="";


    EditText etidpru,etpol;
    Button agregar;
    //primer ws
    TextView tvcodigo,tvcodoperacion,tvoperacion,tvcertificado,tvasegurado,tvpoliza;
    //segundo ws
    TextView tvplaca,tvmoneda;
    //tercer ws
    TextView tvnombre,tvnit;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //DECLARAMOS LOS VALORES DE ENTRADA AL WS 1
        etidpru = (EditText)findViewById(R.id.et_nombre);
        etpol = (EditText)findViewById(R.id.et_apellido);
        agregar= (Button) findViewById(R.id.btn_enviar);

        //DECLARAMOS LOS VALORES A SETEAR
        tvcodigo = (TextView) findViewById(R.id.tv_codigo);
        tvcodoperacion = (TextView) findViewById(R.id.tv_codoperacion);
        tvoperacion = (TextView) findViewById(R.id.tv_operacion);
        tvcertificado = (TextView) findViewById(R.id.tv_certificado);
        tvasegurado = (TextView) findViewById(R.id.tv_asegurado);
        tvpoliza = (TextView) findViewById(R.id.tv_poliza);

        tvmoneda = (TextView) findViewById(R.id.tv_moneda);
        tvplaca = (TextView) findViewById(R.id.tv_placa);

        tvnombre = (TextView) findViewById(R.id.tv_nombre);
        tvnit = (TextView) findViewById(R.id.tv_nit);



        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // OBTENEMOS LA RUTA PARA CONSUMIR EL WEBSERVICE 2
                String a = etidpru.getText().toString();
                String b = etpol.getText().toString();
                String c= a+"-"+b;
                tvpoliza.setText(c);
                WS2conec = "http://190.129.70.58:8079/api/CrdWsFacturacion/ObtienePlanPagos?poliza="+c+"&nrocertificado=";

                WS3conec="http://190.129.70.58:8079/api/ProcesoFacturacion/GetObtieneDatosFactura?idproducto="+a+"&poliza="+b+"&anexos="+c+"&nombre=&nit=";

                consumirServicio();
                Toast.makeText(getApplicationContext(),WS2conec,Toast.LENGTH_LONG).show();
                //CONSUMIMOS EL 2 WEBSERVICE

                ConecGet conecction = new ConecGet();

                try {
                    String response = conecction.execute(WS2conec).get();
                    //leer en jasson

                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject jsonObject= jsonArray.getJSONObject(0);
                    //Toast.makeText(getApplicationContext(),response, Toast.LENGTH_LONG).show();
                    String Moneda=jsonObject.getString("Moneda");
                    String placa=jsonObject.getString("placa");


                    tvmoneda.setText(Moneda);
                    tvplaca.setText(placa);


                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                //CONSUMIMOS EL 3 WEBSERVICE

                ConecGet conecction3 = new ConecGet();

                try {
                    String response3 = conecction3.execute(WS3conec).get();
                    //leer en jasson

                    JSONArray jsonArray3 = new JSONArray(response3);
                    JSONObject jsonObject3= jsonArray3.getJSONObject(0);
                    //Toast.makeText(getApplicationContext(),response, Toast.LENGTH_LONG).show();
                    String nombre=jsonObject3.getString("nombre");
                    String nit=jsonObject3.getString("nit");

                    tvnombre.setText(nombre);
                    tvnit.setText(nit);

                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });

    }

    //CONSUME PARA EL 1 WEB SERVICE
    public void consumirServicio(){
    // ahora ejecutaremos el hilo creado
       // String id= editTextid.getText().toString();
        String id= etidpru.getText().toString();
        String pol= etpol.getText().toString();

        SegundoPlano servicioTask= new SegundoPlano(this,"http://190.129.70.58:8079/api/Buscador/BuscarDatos",id,pol);
        servicioTask.execute();


    }

    //WEB SERVICE 1.Buscador de Pólizas

     class SegundoPlano extends AsyncTask<Void, Void, String> {

        //variables del hilo
        private Context httpContext;//contexto
        ProgressDialog progressDialog;//dialogo cargando
        public String resultadoapi="";
        public String linkrequestAPI="";//link  para consumir el servicio rest
        public String cinit="";
        public String idproducto="";
        public String numpoliza="";
        public String placa="";
        public String idreclamo="";
        public String idcertificado="";
        public String tipo="2";

        //constructor del hilo (Asynctask)
        public SegundoPlano(Context ctx, String linkAPI, String idproducto, String  numpoliza ){
            this.httpContext=ctx;
            this.linkrequestAPI=linkAPI;
            this.idproducto=idproducto;
            this.numpoliza=numpoliza;

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = ProgressDialog.show(httpContext, "Procesando Solicitud", "por favor, espere");
        }

        @Override
        protected String doInBackground(Void... params) {
            String result= null;

            String wsURL = linkrequestAPI;
            URL url = null;
            try {
                // se crea la conexion al api: http://localhost:15009/WEBAPIREST/api/persona
                url = new URL(wsURL);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                //crear el objeto json para enviar por POST
                JSONObject parametrosPost= new JSONObject();
                parametrosPost.put("cinit",cinit);
                parametrosPost.put("idproducto",idproducto);
                parametrosPost.put("numpoliza",numpoliza);
                parametrosPost.put("placa",placa);
                parametrosPost.put("idreclamo",idreclamo);
                parametrosPost.put("idcertificado",idcertificado);
                parametrosPost.put("tipo",tipo);

                //DEFINIR PARAMETROS DE CONEXION
                urlConnection.setReadTimeout(15000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.setRequestMethod("POST");// se puede cambiar por delete ,put ,etc
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);


                //OBTENER EL RESULTADO DEL REQUEST
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(parametrosPost));
                writer.flush();
                writer.close();
                os.close();

                int responseCode=urlConnection.getResponseCode();// conexion OK?
                if(responseCode== HttpURLConnection.HTTP_OK){
                    BufferedReader in= new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                    StringBuffer sb= new StringBuffer("");
                    String linea="";
                    while ((linea=in.readLine())!= null){
                        sb.append(linea);
                        break;

                    }
                    in.close();

                    result= sb.toString();
                }
                else{
                    result= new String("Error: "+ responseCode);


                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }


            return  result;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            progressDialog.dismiss();
            resultadoapi=s;

            //OBTENEMOS EL STRING  PARA VOLVER UN JSON
            try {

                JSONArray jsonArray = new JSONArray(s);
                JSONObject jsonObject= jsonArray.getJSONObject(0);
                //Toast.makeText(getApplicationContext(),response, Toast.LENGTH_LONG).show();

                //OBTENEMOS LOS RESULTADOS POST
                String codigo=jsonObject.getString("codigo");
                String codoperacion=jsonObject.getString("codoperacion");
                String operacion=jsonObject.getString("operacion");
                String certificado=jsonObject.getString("certificado");
                String asegurado=jsonObject.getString("asegurado");

                //SETEAMOS LAS VARIABLES
                tvcodigo.setText(codigo);
                tvcodoperacion.setText(codoperacion);
                tvoperacion.setText(operacion);
                tvcertificado.setText(certificado);
                tvasegurado.setText(asegurado);



            } catch (JSONException e) {
                e.printStackTrace();
            }


            //Toast.makeText(httpContext,resultadoapi, Toast.LENGTH_LONG).show();//mostrara una notificacion con el resultado del request

        }
        //FUNCIONES----------------------------------------------------------------------
        //Transformar JSON Obejct a String *******************************************
        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;
            Iterator<String> itr = params.keys();
            while(itr.hasNext()){

                String key= itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));
            }
            return result.toString();
        }

    }




}
